package com.crm.dao;

import com.bjpowernode.crm.workbench.domain.Activity;
import com.bjpowernode.crm.workbench.mapper.ActivityMapper;
import com.crm.BaseTest;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.List;

/**
 * 动力节点
 * 2021/3/26
 */
public class ActivityDaoTest extends BaseTest {

    @Autowired
    private ActivityMapper activityMapper;

    @Test
    public void testselectActivityForPageByCondition(){
        HashMap map=new HashMap();
        map.put("name","1");
        map.put("beginNo", 0);
        map.put("pageSize",2);
        List<Activity> activityList=activityMapper.selectActivityForPageByCondition(map);
        System.out.println(activityList.size());

    }

    @Test
    public void testselectCountOfActivityByCondition(){
        HashMap map=new HashMap();
        long count=activityMapper.selectCountOfActivityByCondition(map);
        System.out.println(count);

    }

    @Test
    public void testsearchActivityNotBoundById(){
        HashMap map=new HashMap();
        map.put("activityName","");
        map.put("clueId","01b41229673949f7a8196215332aaa70");
        List<Activity> activityList=activityMapper.searchActivityNotBoundById(map);
        System.out.println(activityList.size());

    }
}
