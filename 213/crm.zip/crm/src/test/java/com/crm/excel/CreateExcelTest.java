package com.crm.excel;

import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.HorizontalAlignment;

import java.io.FileOutputStream;
import java.io.OutputStream;

/**
 * 动力节点
 * 2021/3/29
 */
public class CreateExcelTest {
    public static void main(String[] args) throws Exception{
        //1.创建一个excel文件
        HSSFWorkbook wb=new HSSFWorkbook();
        //2.创建一个表
        HSSFSheet sheet=wb.createSheet("学生列表");
        //3.创建行,第一行是0
        HSSFRow row=sheet.createRow(0);
        //4.创建列，单元格,第一列是0
        HSSFCell cell=row.createCell(0);
        //5.在单元格写入数据
         cell.setCellValue("学号");

         //向第2列
        cell=row.createCell(1);
        cell.setCellValue("姓名");

        //向第3列
        cell=row.createCell(2);
        cell.setCellValue("年龄");

        //创建样式对象
        HSSFCellStyle style=wb.createCellStyle();
        //对齐方式
        style.setAlignment(HorizontalAlignment.CENTER);

        //继续添加数据
        for(int i=1;i<=10;i++){
            row=sheet.createRow(i);
            cell=row.createCell(0);
            cell.setCellStyle(style);
            cell.setCellValue(100+i);

            cell=row.createCell(1);
            cell.setCellStyle(style);
            cell.setCellValue("tom"+i);

            cell=row.createCell(2);
            cell.setCellStyle(style);
            cell.setCellValue(20+i);
        }

        //输出流
        OutputStream os=new FileOutputStream("d:\\student.xlsx");
       //wb对象就是一个Excel对象，使用os将wb输出
        wb.write(os);

        os.close();
        wb.close();
        System.out.println("----------------end-------------------");

    }
}
