package com.bjpowernode.crm.service;

/**
 * 动力节点
 * 2021/3/17
 */
public interface User {
}
