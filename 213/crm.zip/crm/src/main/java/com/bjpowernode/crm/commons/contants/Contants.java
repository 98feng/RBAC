package com.bjpowernode.crm.commons.contants;

/**
 * 动力节点
 * 2021/3/20
 */
public class Contants {
    public static final String RETURN_OBJECT_CODE_SUCCESS="1";
    public static final String RETURN_OBJECT_CODE_FAIL="0";

    public static final String SESSION_USER="sessionUser";

}
